Тестовое задание skylogic
